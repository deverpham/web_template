function UpdateBalance() {
    
    $.get('/api/balance', function(data)  {
        $('.symbol').text(data.message.currency)
        $('.amount').text(data.message.funds)
        $('.funds').addClass('animated update')
    })
}
module.exports = UpdateBalance;