var handlingError = (response) => {
    alert('Error:' + response.responseText);
}
module.exports = handlingError;