const gdax = require('../service/gdax');
const runner = require('../service/runner')
module.exports  = (function() {
    return {
        init : function() {
            gdax.start();
            runner.start();
        }
    }
}())